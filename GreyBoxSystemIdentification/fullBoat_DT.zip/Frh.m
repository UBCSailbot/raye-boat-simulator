function hull_resistance = Frh(v_ah)
Constants_Oct_15_2019
    hull_resistance = k_rh*v_ah^2;

end