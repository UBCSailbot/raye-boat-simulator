%Sampling and system constants
Ts = 0.5;
ny = 8;
nu = 2;
nx = 8;
init_time = 0;
final_time = 10;
N = 1 + (final_time - init_time)/Ts;
Parameters    = [1]; %first guess for estimated parameters
y = randn(N, ny);
u = randn(N, nu);
z = iddata(y, u, Ts);
z.InputName = {'Sail Angle', 'Rudder Angle'};
z.InputUnit =  {'rad', 'rad'};
z.OutputName = {'X', 'Y', 'phi', 'psi', 'surge', 'sway', 'roll', 'yaw' };
z.OutputUnit = {'m', 'm', 'rad', 'rad', 'm/s', 'm/s', 'rad/s', 'rad/s' };
z.Tstart = 0;
z.TimeUnit = 's';

FileName      = 'fullBoat_CTS1';       
Order         = [ny nu nx];           
         
InitialStates = [0;0;0; 0;0;0;0;0];            
Ts            = 0;  

nlgr = idnlgrey('fullBoat_CTS1', Order, Parameters, InitialStates, Ts);
set(nlgr, 'InputName', {'Sail Angle', 'Rudder Angle'}, 'InputUnit', {'rad', 'rad'}',               ...
          'OutputName', {'X', 'Y', 'phi', 'psi', 'surge', 'sway', 'roll', 'yaw' }, ...
          'OutputUnit', {'m', 'm', 'rad', 'rad', 'm/s', 'm/s', 'rad/s', 'rad/s' },                         ...
          'TimeUnit', 's');
nlgr = setinit(nlgr, 'Name', {'X', 'Y', 'phi', 'psi', 'surge', 'sway', 'roll', 'yaw' });
nlgr = setinit(nlgr, 'Unit', {'m', 'm', 'rad', 'rad', 'm/s', 'm/s', 'rad/s', 'rad/s' });
nlgr = setpar(nlgr, 'Name', {'Drag Coefficient'});

nlgr = setinit(nlgr, 'Fixed', {false false false false false false false false}); % Estimate the initial states.
opt = nlgreyestOptions('Display', 'on');

nlgr = nlgreyest(z, nlgr, opt );

nlgr.Report
fprintf('\n\nThe search termination condition:\n')
nlgr.Report.Termination
